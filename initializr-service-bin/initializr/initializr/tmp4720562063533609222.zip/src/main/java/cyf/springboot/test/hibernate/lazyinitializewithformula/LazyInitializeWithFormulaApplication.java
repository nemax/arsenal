package cyf.springboot.test.hibernate.lazyinitializewithformula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LazyInitializeWithFormulaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LazyInitializeWithFormulaApplication.class, args);
	}
}
