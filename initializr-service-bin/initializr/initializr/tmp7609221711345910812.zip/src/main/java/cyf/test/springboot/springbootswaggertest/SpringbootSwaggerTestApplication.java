package cyf.test.springboot.springbootswaggertest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSwaggerTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootSwaggerTestApplication.class, args);
	}
}
