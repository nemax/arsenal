package com.cyf.test.h2.h2databasetest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2DatabaseTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2DatabaseTestApplication.class, args);
	}
}
