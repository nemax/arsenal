package cyf.test.redis.redisvaluereader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisValueReaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedisValueReaderApplication.class, args);
	}
}
