//>>built
define("dijit/form/nls/pt-pt/ComboBox",{previousMessage:"Op\u00e7\u00f5es anteriores",nextMessage:"Mais op\u00e7\u00f5es"});
//# sourceMappingURL=ComboBox.js.map