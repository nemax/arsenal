define(
"dojo/cldr/nls/hr/currency", //begin v1.x content
{
	"HKD_displayName": "hongkonški dolar",
	"CHF_displayName": "švicarski franak",
	"JPY_symbol": "¥",
	"CAD_displayName": "kanadski dolar",
	"HKD_symbol": "HKD",
	"CNY_displayName": "kineski yuan",
	"USD_symbol": "USD",
	"AUD_displayName": "australski dolar",
	"JPY_displayName": "japanski jen",
	"CAD_symbol": "CAD",
	"USD_displayName": "američki dolar",
	"CNY_symbol": "CNY",
	"GBP_displayName": "britanska funta",
	"GBP_symbol": "GBP",
	"AUD_symbol": "AUD",
	"EUR_displayName": "euro"
}
//end v1.x content
);